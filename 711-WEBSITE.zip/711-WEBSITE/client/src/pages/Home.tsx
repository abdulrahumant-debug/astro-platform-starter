import { Button } from "@/components/ui/button";
import { Phone, MapPin, Sparkles, CheckCircle2, Shield, Clock } from "lucide-react";
import { motion } from "framer-motion";
import heroImage from "@/assets/images/hero-clean.png";

export default function Home() {
  const phoneNumber = "+965 92235280";
  const displayPhone = "92235280";

  return (
    <div className="min-h-screen bg-white">
      {/* Top Bar */}
      <div className="bg-primary/5 border-b border-primary/10">
        <div className="container mx-auto px-4 py-2 flex justify-between items-center text-sm">
          <div className="flex items-center gap-2 text-muted-foreground">
            <MapPin className="w-4 h-4 text-primary" />
            <span>Proudly based in Kuwait</span>
            <span className="text-xl leading-none ml-1">🇰🇼</span>
          </div>
          <div className="hidden sm:flex items-center gap-2 font-medium text-primary">
            <Clock className="w-4 h-4" />
            <span>Available 24/7</span>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Sparkles className="w-8 h-8 text-primary" />
            <span className="text-2xl font-bold font-display tracking-tight text-gray-900">
              711<span className="text-primary">Clean</span>
            </span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="hidden md:flex flex-col items-end mr-4">
              <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">Call us today</span>
              <span className="text-lg font-bold text-gray-900">{displayPhone}</span>
            </div>
            <a href={`tel:${phoneNumber.replace(/\s+/g, '')}`}>
              <Button size="lg" className="rounded-full shadow-lg shadow-primary/20 hover:shadow-xl hover:shadow-primary/30 transition-all duration-300">
                <Phone className="w-5 h-5 mr-2" />
                <span className="font-semibold">Book Now</span>
              </Button>
            </a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative pt-12 pb-20 lg:pt-24 lg:pb-32 overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="lg:w-1/2 space-y-8"
            >
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary font-medium text-sm">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                </span>
                #1 Cleaning Service in Kuwait 🇰🇼
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold font-display text-gray-900 leading-tight">
                Spotless spaces, <br/>
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">
                  effortless living.
                </span>
              </h1>
              
              <p className="text-xl text-gray-600 leading-relaxed max-w-xl">
                Experience the highest standard of professional cleaning in Kuwait. We transform your home or office into a pristine sanctuary.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <a href={`tel:${phoneNumber.replace(/\s+/g, '')}`} className="w-full sm:w-auto">
                  <Button size="xl" className="w-full sm:w-auto text-lg h-14 px-8 rounded-full shadow-xl shadow-primary/20">
                    <Phone className="w-6 h-6 mr-2" />
                    Call {displayPhone}
                  </Button>
                </a>
              </div>

              <div className="grid grid-cols-2 gap-6 pt-8 border-t border-gray-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center text-green-600">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div className="font-medium text-gray-900">Fully Insured</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600">
                    <CheckCircle2 className="w-5 h-5" />
                  </div>
                  <div className="font-medium text-gray-900">100% Satisfaction</div>
                </div>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="lg:w-1/2 relative"
            >
              <div className="relative rounded-[2.5rem] overflow-hidden shadow-2xl shadow-black/10 aspect-[4/3] group">
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent z-10" />
                <img 
                  src={heroImage} 
                  alt="Spotless clean living room" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                
                {/* Floating Badge */}
                <div className="absolute bottom-6 left-6 right-6 z-20 bg-white/90 backdrop-blur-md rounded-2xl p-4 shadow-xl flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="bg-primary/10 p-3 rounded-xl text-primary">
                      <Sparkles className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="text-sm text-gray-500 font-medium">Local Experts</div>
                      <div className="font-bold text-gray-900 text-lg flex items-center gap-2">
                        Kuwait Based 🇰🇼
                      </div>
                    </div>
                  </div>
                  <a href={`tel:${phoneNumber.replace(/\s+/g, '')}`}>
                    <Button variant="default" className="rounded-xl shadow-md">
                      Call Now
                    </Button>
                  </a>
                </div>
              </div>
              
              {/* Decorative blobs */}
              <div className="absolute -top-12 -right-12 w-64 h-64 bg-primary/20 rounded-full blur-3xl -z-10" />
              <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-blue-400/20 rounded-full blur-3xl -z-10" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Snapshot */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold font-display text-gray-900 mb-4">Why Choose 711Clean?</h2>
            <p className="text-gray-600 text-lg">We bring unparalleled cleanliness and hygiene to homes and businesses across Kuwait.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Deep Cleaning", desc: "Thorough sanitization of every corner, leaving no dust behind." },
              { title: "Trusted Professionals", desc: "Our staff is vetted, trained, and highly experienced." },
              { title: "Eco-Friendly", desc: "We use safe, environmentally friendly products for your family's health." }
            ].map((service, i) => (
              <div key={i} className="bg-white p-8 rounded-3xl shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
                <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary mb-6">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-bold mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer CTA */}
      <section className="bg-primary py-16 lg:py-24 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl lg:text-5xl font-bold text-white mb-6 font-display">Ready for a cleaner space?</h2>
          <p className="text-primary-foreground/80 text-xl mb-10 max-w-2xl mx-auto">
            Join hundreds of satisfied customers in Kuwait. Contact us today for a free quote.
          </p>
          <a href={`tel:${phoneNumber.replace(/\s+/g, '')}`}>
            <Button size="xl" variant="secondary" className="text-lg h-14 px-8 rounded-full text-primary hover:bg-white/90">
              <Phone className="w-6 h-6 mr-2" />
              Call {displayPhone}
            </Button>
          </a>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-900 py-8 text-gray-400 text-center text-sm">
        <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            <span className="text-xl font-bold font-display text-white">
              711<span className="text-primary">Clean</span>
            </span>
          </div>
          <p>© {new Date().getFullYear()} 711Clean. Proudly serving Kuwait 🇰🇼</p>
          <div className="flex gap-4">
            <a href={`tel:${phoneNumber.replace(/\s+/g, '')}`} className="hover:text-white transition-colors">
              {phoneNumber}
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}